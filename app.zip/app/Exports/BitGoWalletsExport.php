<?php

namespace App\Exports;

use App\Models\BitGoWallet;
use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class BitGoWalletsExport implements FromQuery, WithHeadings, WithMapping
{
    protected $filters;

    public function __construct(array $filters = [])
    {
        $this->filters = $filters;
    }

    public function query()
    {
        $query = BitGoWallet::with('user', 'currency');

        if (!empty($this->filters['user'])) {
            $query->whereHas('user', function ($q) {
                $q->where('first_name', 'like', '%' . $this->filters['user'] . '%')
                  ->orWhere('last_name', 'like', '%' . $this->filters['user'] . '%')
                  ->orWhere('email', 'like', '%' . $this->filters['user'] . '%');
            });
        }

        if (!empty($this->filters['currency'])) {
            $query->whereHas('currency', function ($q) {
                $q->where('code', $this->filters['currency']);
            });
        }

        return $query;
    }

    public function headings(): array
    {
        return [
            'User ID',
            'User Name',
            'User Email',
            'Currency',
            'BitGo Wallet ID',
            'BitGo Address',
            'Created At',
        ];
    }

    public function map($wallet): array
    {
        return [
            $wallet->user_id,
            $wallet->user ? $wallet->user->first_name . ' ' . $wallet->user->last_name : 'N/A',
            $wallet->user ? $wallet->user->email : 'N/A',
            $wallet->currency ? $wallet->currency->name . ' (' . $wallet->currency->code . ')' : 'N/A',
            $wallet->bitgo_wallet_id,
            $wallet->bitgo_address,
            $wallet->created_at->format('Y-m-d H:i:s'),
        ];
    }
}
