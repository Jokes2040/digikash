<?php

namespace App\Services;

use App\Models\BitGoSetting;
use App\Models\BitGoWallet;
use App\Models\Currency;
use App\Models\User;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class BitGoService
{
    protected string $baseUrl;
    protected ?string $apiKey = null;
    protected ?string $webhookSecret = null;
    protected ?string $walletPassphrase = null;

    public function __construct()
    {
        $this->baseUrl = config('services.bitgo.base_url', 'https://app.bitgo.com/api/v2');
        try {
            $this->loadCredentials();
        } catch (\Exception $e) {
            // Table might not exist yet during migration
            Log::warning('BitGo credentials not loaded: ' . $e->getMessage());
        }
    }

    /**
     * Load credentials from database with caching.
     */
    protected function loadCredentials(string $environment = 'production'): void
    {
        $cacheKey = "bitgo_settings_{$environment}";
        $settings = Cache::remember($cacheKey, 3600, function () use ($environment) {
            return BitGoSetting::forEnvironment($environment);
        });

        if ($settings) {
            $this->apiKey = $settings->api_key;
            $this->webhookSecret = $settings->webhook_secret;
            $this->walletPassphrase = $settings->wallet_passphrase;
        }
    }

    /**
     * Create a BitGo wallet for a given currency.
     */
    public function createWallet(Currency $currency): array
    {
        if (!$this->apiKey || !$this->walletPassphrase) {
            throw new \Exception('BitGo credentials not configured');
        }

        $response = Http::withToken($this->apiKey)->post("{$this->baseUrl}/{$currency->code}/wallet", [
            'label' => "Platform Wallet - {$currency->name}",
            'passphrase' => $this->walletPassphrase,
        ]);

        if ($response->failed()) {
            Log::error('BitGo wallet creation failed', ['currency' => $currency->code, 'response' => $response->body()]);
            throw new \Exception('Failed to create BitGo wallet');
        }

        return $response->json();
    }

    /**
     * Generate an address for a BitGo wallet.
     */
    public function generateAddress(string $bitgoWalletId, string $currencyCode): array
    {
        if (!$this->apiKey) {
            throw new \Exception('BitGo credentials not configured');
        }

        $response = Http::withToken($this->apiKey)->post("{$this->baseUrl}/{$currencyCode}/wallet/{$bitgoWalletId}/address");

        if ($response->failed()) {
            Log::error('BitGo address generation failed', ['wallet_id' => $bitgoWalletId, 'response' => $response->body()]);
            throw new \Exception('Failed to generate BitGo address');
        }

        return $response->json();
    }

    /**
     * Send a withdrawal (transfer) from BitGo wallet.
     */
    public function sendTransfer(string $bitgoWalletId, string $currencyCode, string $destinationAddress, float $amount, string $idempotencyKey): array
    {
        $response = Http::withToken($this->apiKey)->post("{$this->baseUrl}/{$currencyCode}/wallet/{$bitgoWalletId}/sendcoins", [
            'address' => $destinationAddress,
            'amount' => $this->convertToSatoshis($amount, $currencyCode),
            'walletPassphrase' => config('services.bitgo.wallet_passphrase'),
            'idempotencyKey' => $idempotencyKey,
        ]);

        if ($response->failed()) {
            Log::error('BitGo transfer failed', ['wallet_id' => $bitgoWalletId, 'response' => $response->body()]);
            throw new \Exception('Failed to send BitGo transfer');
        }

        return $response->json();
    }

    /**
     * Verify BitGo webhook signature.
     */
    public function verifyWebhookSignature(string $payload, string $signature): bool
    {
        if (!$this->webhookSecret) {
            return false;
        }

        $expectedSignature = hash_hmac('sha256', $payload, $this->webhookSecret);
        return hash_equals($expectedSignature, $signature);
    }

    /**
     * Convert amount to satoshis for Bitcoin-like currencies.
     */
    protected function convertToSatoshis(float $amount, string $currencyCode): int
    {
        // Assuming 8 decimal places for crypto; adjust as needed
        return (int) ($amount * 100000000);
    }
}
