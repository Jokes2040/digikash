<?php

namespace App\Services;

use App\Enums\TrxType;
use App\Enums\TrxStatus;
use App\Enums\AmountFlow;
use App\Models\BitGoWallet;
use App\Models\Transaction;
use App\Models\Withdrawal;
use App\Models\User;
use App\Services\BitGoService;
use App\Services\WalletService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class WithdrawalService
{
    protected BitGoService $bitGoService;
    protected WalletService $walletService;

    public function __construct(BitGoService $bitGoService, WalletService $walletService)
    {
        $this->bitGoService = $bitGoService;
        $this->walletService = $walletService;
    }

    /**
     * Process a withdrawal request.
     */
    public function processWithdrawal(User $user, array $data): Withdrawal
    {
        $currencyCode = $data['currency'];
        $amount = $data['amount'];
        $destinationAddress = $data['address'];

        // Get user's wallet for this currency
        $wallet = $user->wallets()->whereHas('currency', function ($query) use ($currencyCode) {
            $query->where('code', $currencyCode);
        })->first();

        if (!$wallet) {
            throw new \Exception('Wallet not found for currency');
        }

        // Check balance
        if ($wallet->balance < $amount) {
            throw new \Exception('Insufficient balance');
        }

        // Get BitGo wallet for this currency
        $bitGoWallet = BitGoWallet::where('currency_id', $wallet->currency_id)->first();
        if (!$bitGoWallet) {
            throw new \Exception('BitGo wallet not configured for this currency');
        }

        $idempotencyKey = Str::uuid()->toString();

        DB::transaction(function () use ($user, $data, $wallet, $bitGoWallet, $idempotencyKey, $amount, $destinationAddress, $currencyCode) {
            // Create withdrawal record
            $withdrawal = Withdrawal::create([
                'user_id' => $user->id,
                'currency' => $currencyCode,
                'amount' => $amount,
                'destination_address' => $destinationAddress,
                'status' => 'pending',
                'idempotency_key' => $idempotencyKey,
            ]);

            // Debit the user's wallet immediately
            $this->walletService->subtractMoney($wallet, $amount);

            // Create transaction record
            Transaction::create([
                'user_id' => $user->id,
                'trx_type' => TrxType::WITHDRAW,
                'description' => "Crypto withdrawal via BitGo",
                'amount' => $amount,
                'amount_flow' => AmountFlow::MINUS,
                'currency' => $currencyCode,
                'net_amount' => $amount,
                'wallet_reference' => $wallet->uuid,
                'status' => TrxStatus::PENDING,
            ]);

            // Submit to BitGo
            try {
                $transferData = $this->bitGoService->sendTransfer(
                    $bitGoWallet->bitgo_wallet_id,
                    $currencyCode,
                    $destinationAddress,
                    $amount,
                    $idempotencyKey
                );

                $withdrawal->update([
                    'status' => 'submitted',
                    'bitgo_tx_id' => $transferData['transfer']['id'],
                    'tx_hash' => $transferData['txid'] ?? null,
                ]);

                Log::info('Withdrawal submitted to BitGo', ['withdrawal_id' => $withdrawal->id, 'bitgo_tx_id' => $transferData['transfer']['id']]);
            } catch (\Exception $e) {
                // Revert the debit if BitGo submission fails
                $this->walletService->addMoney($wallet, $amount);
                $withdrawal->update(['status' => 'failed']);
                throw $e;
            }
        });

        return Withdrawal::where('idempotency_key', $idempotencyKey)->first();
    }

    /**
     * Handle BitGo withdrawal confirmation webhook.
     */
    public function handleWithdrawalConfirmation(string $bitgoTxId, string $status)
    {
        $withdrawal = Withdrawal::where('bitgo_tx_id', $bitgoTxId)->first();
        if (!$withdrawal) {
            Log::warning('Withdrawal not found for BitGo TX ID', ['bitgo_tx_id' => $bitgoTxId]);
            return;
        }

        if ($status === 'confirmed') {
            $withdrawal->update(['status' => 'confirmed']);

            // Update transaction status
            $transaction = Transaction::where('user_id', $withdrawal->user_id)
                ->where('trx_type', TrxType::WITHDRAW)
                ->where('amount', $withdrawal->amount)
                ->where('status', TrxStatus::PENDING)
                ->latest()
                ->first();

            if ($transaction) {
                $transaction->update(['status' => TrxStatus::COMPLETED]);
            }

            Log::info('Withdrawal confirmed', ['withdrawal_id' => $withdrawal->id]);
        } elseif ($status === 'failed') {
            $withdrawal->update(['status' => 'failed']);

            // Refund the user
            $wallet = $withdrawal->user->wallets()->whereHas('currency', function ($query) use ($withdrawal) {
                $query->where('code', $withdrawal->currency);
            })->first();

            if ($wallet) {
                $this->walletService->addMoney($wallet, $withdrawal->amount);
            }

            Log::info('Withdrawal failed, refunded user', ['withdrawal_id' => $withdrawal->id]);
        }
    }
}
