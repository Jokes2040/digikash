<?php

namespace App\Services\Custody\Repositories;

use App\Services\Custody\Models\CustodialWalletBalance;
use Illuminate\Support\Facades\DB;

class CustodialWalletBalanceRepository
{
    public function getAvailableBalance($walletId)
    {
        $balance = CustodialWalletBalance::where('custodial_wallet_id', $walletId)->first();
        return $balance ? $balance->available : 0;
    }

    public function creditBalance($walletId, $amount)
    {
        return DB::transaction(function () use ($walletId, $amount) {
            $balance = CustodialWalletBalance::where('custodial_wallet_id', $walletId)->lockForUpdate()->first();
            if (!$balance) {
                $balance = CustodialWalletBalance::create([
                    'custodial_wallet_id' => $walletId,
                    'total' => 0,
                    'available' => 0,
                    'reserved' => 0,
                ]);
            }
            $balance->increment('total', $amount);
            $balance->increment('available', $amount);
            return $balance;
        });
    }

    public function debitBalance($walletId, $amount)
    {
        return DB::transaction(function () use ($walletId, $amount) {
            $balance = CustodialWalletBalance::where('custodial_wallet_id', $walletId)->lockForUpdate()->first();
            if (!$balance || $balance->available < $amount) {
                throw new \Exception('Insufficient available balance');
            }
            $balance->decrement('total', $amount);
            $balance->decrement('available', $amount);
            return $balance;
        });
    }

    public function updateBalance($walletId, $amount, $type)
    {
        return DB::transaction(function () use ($walletId, $amount, $type) {
            $balance = CustodialWalletBalance::where('custodial_wallet_id', $walletId)->lockForUpdate()->first();
            if (!$balance) {
                throw new \Exception('Balance not found');
            }
            if ($type === 'withdraw') {
                $balance->decrement('available', $amount);
                $balance->decrement('total', $amount);
            } elseif ($type === 'deposit') {
                $balance->increment('available', $amount);
                $balance->increment('total', $amount);
            } else {
                throw new \Exception('Invalid balance update type');
            }
            return $balance;
        });
    }
}
