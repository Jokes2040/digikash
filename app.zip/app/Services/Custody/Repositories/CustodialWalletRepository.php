<?php

namespace App\Services\Custody\Repositories;

use App\Services\Custody\Models\CustodialWallet;
use Illuminate\Support\Facades\DB;

class CustodialWalletRepository
{
    public function getAll()
    {
        return CustodialWallet::all();
    }

    public function findById($id)
    {
        return CustodialWallet::findOrFail($id);
    }

    public function create(array $data)
    {
        return CustodialWallet::create($data);
    }

    public function update(CustodialWallet $wallet, array $data)
    {
        $wallet->update($data);
        return $wallet;
    }

    public function reserveFunds($walletId, $amount)
    {
        return DB::transaction(function () use ($walletId, $amount) {
            $balance = CustodialWallet::findOrFail($walletId)->balance()->lockForUpdate()->first();
            if (!$balance || $balance->available < $amount) {
                throw new \Exception('Insufficient available balance');
            }
            $balance->decrement('available', $amount);
            $balance->increment('reserved', $amount);
            return $balance;
        });
    }

    public function releaseFunds($walletId, $amount)
    {
        return DB::transaction(function () use ($walletId, $amount) {
            $balance = CustodialWallet::findOrFail($walletId)->balance()->lockForUpdate()->first();
            if (!$balance || $balance->reserved < $amount) {
                throw new \Exception('Insufficient reserved balance');
            }
            $balance->increment('available', $amount);
            $balance->decrement('reserved', $amount);
            return $balance;
        });
    }

    public function commitFunds($walletId, $amount)
    {
        return DB::transaction(function () use ($walletId, $amount) {
            $balance = CustodialWallet::findOrFail($walletId)->balance()->lockForUpdate()->first();
            if (!$balance || $balance->reserved < $amount) {
                throw new \Exception('Insufficient reserved balance');
            }
            $balance->decrement('reserved', $amount);
            $balance->decrement('total', $amount);
            return $balance;
        });
    }
}
