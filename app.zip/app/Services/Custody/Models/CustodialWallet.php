<?php

namespace App\Services\Custody\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Crypt;

class CustodialWallet extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'currency',
        'chain',
        'rpc_url',
        'hot_wallet_address',
        'encrypted_signing_key',
        'enabled',
        'confirmations_required',
        'notes',
    ];

    protected $casts = [
        'enabled' => 'boolean',
        'confirmations_required' => 'integer',
    ];

    public function balance()
    {
        return $this->hasOne(CustodialWalletBalance::class);
    }

    public function setEncryptedSigningKeyAttribute($value)
    {
        $this->attributes['encrypted_signing_key'] = $value ? Crypt::encryptString($value) : null;
    }

    public function getEncryptedSigningKeyAttribute($value)
    {
        return $value ? Crypt::decryptString($value) : null;
    }
}
