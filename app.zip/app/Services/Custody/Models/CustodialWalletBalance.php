<?php

namespace App\Services\Custody\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CustodialWalletBalance extends Model
{
    use HasFactory;

    protected $fillable = [
        'custodial_wallet_id',
        'total',
        'available',
        'reserved',
    ];

    protected $casts = [
        'total' => 'decimal:8',
        'available' => 'decimal:8',
        'reserved' => 'decimal:8',
    ];

    public function wallet()
    {
        return $this->belongsTo(CustodialWallet::class, 'custodial_wallet_id');
    }
}
