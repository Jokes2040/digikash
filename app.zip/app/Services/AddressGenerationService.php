<?php

namespace App\Services;

use App\Models\BitGoWallet;
use App\Models\Currency;
use App\Models\User;
use App\Services\BitGoService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class AddressGenerationService
{
    protected BitGoService $bitGoService;

    public function __construct(BitGoService $bitGoService)
    {
        $this->bitGoService = $bitGoService;
    }

    /**
     * Generate a BitGo wallet and address for a user and currency.
     */
    public function generateAddress(User $user, string $currencyCode): BitGoWallet
    {
        $currency = Currency::where('code', $currencyCode)->first();
        if (!$currency) {
            throw new \Exception('Currency not found');
        }

        // Check if user already has a BitGo wallet for this currency
        $existingWallet = BitGoWallet::where('user_id', $user->id)
            ->where('currency_id', $currency->id)
            ->first();

        if ($existingWallet) {
            return $existingWallet;
        }

        // Check if BitGo wallet exists for this currency (shared across users)
        $bitGoWallet = BitGoWallet::where('currency_id', $currency->id)->first();

        if (!$bitGoWallet) {
            // Create new BitGo wallet for this currency
            $walletData = $this->bitGoService->createWallet($currency);
            $bitGoWalletId = $walletData['id'];

            // Generate address for the wallet
            $addressData = $this->bitGoService->generateAddress($bitGoWalletId, $currencyCode);
            $address = $addressData['address'];

            // Create BitGoWallet record (shared for currency)
            $bitGoWallet = BitGoWallet::create([
                'user_id' => null, // Shared wallet
                'currency_id' => $currency->id,
                'bitgo_wallet_id' => $bitGoWalletId,
                'bitgo_address' => $address,
            ]);
        }

        // Create user-specific BitGoWallet entry pointing to the shared wallet
        return BitGoWallet::create([
            'user_id' => $user->id,
            'currency_id' => $currency->id,
            'bitgo_wallet_id' => $bitGoWallet->bitgo_wallet_id,
            'bitgo_address' => $bitGoWallet->bitgo_address,
        ]);
    }
}
