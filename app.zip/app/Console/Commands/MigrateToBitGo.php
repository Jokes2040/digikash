<?php

namespace App\Console\Commands;

use App\Models\BitGoWallet;
use App\Models\Currency;
use App\Models\User;
use App\Services\BitGoService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class MigrateToBitGo extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'bitgo:migrate {--dry-run : Run without making changes}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Migrate existing crypto balances to BitGo custody';

    protected BitGoService $bitGoService;

    public function __construct(BitGoService $bitGoService)
    {
        parent::__construct();
        $this->bitGoService = $bitGoService;
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $dryRun = $this->option('dry-run');

        if ($dryRun) {
            $this->info('Running in dry-run mode. No changes will be made.');
        }

        // Get all crypto currencies
        $cryptoCurrencies = Currency::where('type', 'crypto')->get();

        if ($cryptoCurrencies->isEmpty()) {
            $this->error('No crypto currencies found.');
            return;
        }

        $this->info('Starting BitGo migration...');

        foreach ($cryptoCurrencies as $currency) {
            $this->info("Processing currency: {$currency->code}");

            // Create BitGo wallet for this currency (shared across users)
            $bitGoWalletData = $this->bitGoService->createWallet($currency->code, "Shared {$currency->name} Wallet");

            if (!$bitGoWalletData) {
                $this->error("Failed to create BitGo wallet for {$currency->code}");
                continue;
            }

            $bitGoWalletId = $bitGoWalletData['id'];
            $bitGoAddress = $bitGoWalletData['receiveAddress']['address'];

            if (!$dryRun) {
                BitGoWallet::create([
                    'user_id' => null, // Shared wallet
                    'currency_id' => $currency->id,
                    'bitgo_wallet_id' => $bitGoWalletId,
                    'bitgo_address' => $bitGoAddress,
                ]);
            }

            $this->info("Created BitGo wallet: {$bitGoWalletId} with address: {$bitGoAddress}");

            // Get all users with balances in this currency
            $usersWithBalance = User::whereHas('wallets', function ($query) use ($currency) {
                $query->where('currency_id', $currency->id)
                      ->where('balance', '>', 0);
            })->with(['wallets' => function ($query) use ($currency) {
                $query->where('currency_id', $currency->id);
            }])->get();

            foreach ($usersWithBalance as $user) {
                $wallet = $user->wallets->first();
                $balance = $wallet->balance;

                $this->info("User {$user->username}: {$balance} {$currency->code}");

                // In a real migration, you would:
                // 1. Transfer funds from old system to BitGo wallet
                // 2. Update internal ledger to reflect BitGo custody
                // 3. Create migration transaction records

                if (!$dryRun) {
                    // Transfer existing balance to BitGo (placeholder - implement actual transfer)
                    $transferResult = $this->bitGoService->sendTransfer(
                        $bitGoWalletId,
                        $currency->code,
                        $bitGoAddress, // Self-transfer to consolidate
                        $balance,
                        'migration-' . $user->id . '-' . time()
                    );

                    if ($transferResult) {
                        Log::info('Migrated balance to BitGo', [
                            'user_id' => $user->id,
                            'currency' => $currency->code,
                            'amount' => $balance,
                            'bitgo_tx_id' => $transferResult['transfer']['id'],
                        ]);
                    }
                }
            }
        }

        $this->info('Migration completed successfully.');
        $this->warn('Remember to:');
        $this->warn('1. Verify all balances match between internal ledger and BitGo');
        $this->warn('2. Enable BitGo webhooks');
        $this->warn('3. Disable old crypto deposit/withdrawal flows');
        $this->warn('4. Monitor for 24-48 hours before full cutover');
    }
}
