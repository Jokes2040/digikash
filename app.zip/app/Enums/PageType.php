<?php

namespace App\Enums;

enum PageType: string
{
    case Static  = 'static';
    case Dynamic = 'dynamic';
}
