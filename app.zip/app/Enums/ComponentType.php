<?php

namespace App\Enums;

enum ComponentType: string
{
    case Static  = 'static';
    case Dynamic = 'dynamic';
}
