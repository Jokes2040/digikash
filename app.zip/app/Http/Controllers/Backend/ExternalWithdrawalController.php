<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Services\ExternalWithdrawal\Models\Withdrawal;
use App\Services\ExternalWithdrawal\Models\BlockchainSetting;
use App\Services\ExternalWithdrawal\Repositories\WithdrawalRepository;
use App\Services\ExternalWithdrawal\Repositories\BlockchainSettingRepository;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;

class ExternalWithdrawalController extends Controller
{
    public function __construct(
        protected WithdrawalRepository $withdrawalRepo,
        protected BlockchainSettingRepository $blockchainRepo
    ) {}

    public function index(): View
    {
        $totalWithdrawals = $this->withdrawalRepo->getPendingWithdrawals()->count();
        $completedWithdrawals = Withdrawal::where('status', 'confirmed')->count();
        $failedWithdrawals = Withdrawal::where('status', 'failed')->count();

        $pendingWithdrawals = Withdrawal::with('user')
            ->whereIn('status', ['pending', 'processing'])
            ->orderBy('created_at', 'desc')
            ->limit(50)
            ->get();

        return view('backend.external_withdrawal.index', compact('totalWithdrawals', 'completedWithdrawals', 'failedWithdrawals', 'pendingWithdrawals'));
    }

    public function history(Request $request): View
    {
        $withdrawals = Withdrawal::with('user')
            ->when($request->status, fn($q) => $q->where('status', $request->status))
            ->when($request->search, fn($q) => $q->where('trx_id', 'like', "%{$request->search}%"))
            ->paginate(20);

        return view('backend.external_withdrawal.history', compact('withdrawals'));
    }

    public function blockchainSettings(): View
    {
        $settings = $this->blockchainRepo->getAll();

        return view('backend.external_withdrawal.blockchain_settings', compact('settings'));
    }

    public function updateBlockchainSettings(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'settings' => 'required|array',
            'settings.*.chain_name' => 'required|string',
            'settings.*.rpc_url' => 'required|url',
            'settings.*.hot_wallet_public_address' => 'required|string',
            'settings.*.encrypted_signing_key' => 'nullable|string',
            'settings.*.enabled' => 'boolean',
            'settings.*.fee_fixed' => 'nullable|numeric',
            'settings.*.fee_percent' => 'nullable|numeric|min:0|max:100',
            'settings.*.min_withdrawal' => 'nullable|numeric',
            'settings.*.max_withdrawal' => 'nullable|numeric',
        ]);

        foreach ($validated['settings'] as $settingData) {
            $setting = $this->blockchainRepo->findByChain($settingData['chain_name']);
            if ($setting) {
                $this->blockchainRepo->update($setting, $settingData);
            } else {
                $this->blockchainRepo->create($settingData);
            }
        }

        notifyEvs('success', 'Blockchain settings updated successfully');

        return redirect()->back();
    }
}
