<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\BitGoAlert;
use App\Models\BitGoAuditLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BitGoAlertsController extends Controller
{
    /**
     * Display alerts.
     */
    public function index(Request $request)
    {
        $query = BitGoAlert::with(['user', 'transaction', 'webhookEvent']);

        // Apply filters
        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }

        if ($request->filled('severity')) {
            $query->where('severity', $request->severity);
        }

        if ($request->filled('status')) {
            if ($request->status === 'resolved') {
                $query->whereNotNull('resolved_at');
            } else {
                $query->whereNull('resolved_at');
            }
        }

        if ($request->filled('user_id')) {
            $query->where('user_id', $request->user_id);
        }

        $alerts = $query->latest()->paginate(20);

        return view('backend.bitgo.alerts.index', compact('alerts'));
    }

    /**
     * Resolve an alert.
     */
    public function resolve(BitGoAlert $alert)
    {
        if ($alert->resolved_at) {
            return back()->withErrors('Alert is already resolved.');
        }

        $alert->update([
            'resolved_at' => now(),
            'resolved_by' => Auth::id(),
        ]);

        // Log audit
        BitGoAuditLog::create([
            'admin_id' => Auth::id(),
            'environment' => 'production', // or get from settings
            'action' => 'alert_resolved',
            'old_values' => ['resolved_at' => null],
            'new_values' => ['resolved_at' => now()],
            'changed_at' => now(),
        ]);

        return back()->with('success', 'Alert resolved successfully.');
    }
}
