<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\BitGoAuditLog;
use App\Models\BitGoSetting;
use App\Services\BitGoService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Validator;

class BitGoSettingsController extends Controller
{
    protected BitGoService $bitGoService;

    public function __construct(BitGoService $bitGoService)
    {
        $this->bitGoService = $bitGoService;
    }

    /**
     * Display the BitGo settings page.
     */
    public function index()
    {
        $settings = BitGoSetting::all();
        $setting = BitGoSetting::forEnvironment('production');
        $auditLogs = BitGoAuditLog::with('admin')->latest()->limit(50)->get();

        return view('backend.bitgo_settings.index', compact('settings', 'setting', 'auditLogs'));
    }

    /**
     * Update BitGo settings for an environment.
     */
    public function update(Request $request, $environment)
    {
        $validator = Validator::make($request->all(), [
            'api_key' => 'required|string',
            'webhook_secret' => 'required|string',
            'wallet_passphrase' => 'required|string',
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        // Test the API key with BitGo before saving
        try {
            $this->testBitGoConnection($request->api_key);
        } catch (\Exception $e) {
            return back()->withErrors(['api_key' => 'Invalid API key or unable to connect to BitGo: ' . $e->getMessage()])->withInput();
        }

        $setting = BitGoSetting::where('environment', $environment)->first();
        $oldValues = $setting ? [
            'api_key' => $setting->masked_api_key,
            'webhook_secret' => $setting->masked_webhook_secret,
            'wallet_passphrase' => $setting->masked_wallet_passphrase,
        ] : null;

        if ($setting) {
            $setting->update($request->only(['api_key', 'webhook_secret', 'wallet_passphrase']));
        } else {
            $setting = BitGoSetting::create(array_merge($request->only(['api_key', 'webhook_secret', 'wallet_passphrase']), ['environment' => $environment]));
        }

        // Clear cache
        Cache::forget("bitgo_settings_{$environment}");

        // Log audit
        BitGoAuditLog::create([
            'admin_id' => Auth::id(),
            'environment' => $environment,
            'action' => $oldValues ? 'updated' : 'created',
            'old_values' => $oldValues,
            'new_values' => [
                'api_key' => $setting->masked_api_key,
                'webhook_secret' => $setting->masked_webhook_secret,
                'wallet_passphrase' => $setting->masked_wallet_passphrase,
            ],
            'changed_at' => now(),
        ]);

        return back()->with('success', 'BitGo settings updated successfully.');
    }

    /**
     * Test connection to BitGo API.
     */
    protected function testBitGoConnection(string $apiKey): void
    {
        // Simple test: try to get user info or similar endpoint
        $response = \Illuminate\Support\Facades\Http::withToken($apiKey)
            ->get('https://app.bitgo.com/api/v2/user/me');

        if ($response->failed()) {
            throw new \Exception('API key validation failed');
        }
    }
}
