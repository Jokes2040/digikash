<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\BitGoAlert;
use App\Models\BitGoWallet;
use App\Models\BitGoWebhookEvent;
use App\Models\Transaction;
use App\Enums\TrxType;
use Illuminate\Http\Request;

class BitGoDashboardController extends Controller
{
    /**
     * Display the BitGo dashboard.
     */
    public function index()
    {
        // Recent transactions
        $recentTransactions = Transaction::whereNotNull('bitgo_tx_id')
            ->with('user')
            ->latest()
            ->limit(10)
            ->get();

        // Recent webhooks
        $recentWebhooks = BitGoWebhookEvent::with('user')
            ->latest()
            ->limit(10)
            ->get();

        // Active alerts
        $activeAlerts = BitGoAlert::whereNull('resolved_at')
            ->with(['user', 'transaction'])
            ->latest()
            ->limit(10)
            ->get();

        // Wallet summary
        $walletSummary = BitGoWallet::with('currency', 'user')
            ->selectRaw('currency_id, COUNT(*) as wallet_count')
            ->groupBy('currency_id')
            ->get();

        // Transaction stats (last 30 days)
        $transactionStats = [
            'deposits' => Transaction::where('trx_type', TrxType::DEPOSIT)
                ->whereNotNull('bitgo_tx_id')
                ->whereDate('created_at', '>=', now()->subDays(30))
                ->count(),
            'withdrawals' => Transaction::where('trx_type', TrxType::WITHDRAW)
                ->whereNotNull('bitgo_tx_id')
                ->whereDate('created_at', '>=', now()->subDays(30))
                ->count(),
        ];

        return view('backend.bitgo.dashboard', compact(
            'recentTransactions',
            'recentWebhooks',
            'activeAlerts',
            'walletSummary',
            'transactionStats'
        ));
    }
}
