<?php

namespace App\Http\Controllers\Admin;

use App\Exports\BitGoWalletsExport;
use App\Http\Controllers\Controller;
use App\Models\BitGoWallet;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

class BitGoWalletsController extends Controller
{
    /**
     * Display a listing of BitGo wallets.
     */
    public function index(Request $request)
    {
        $query = BitGoWallet::with('user', 'currency');

        // Apply filters
        if ($request->filled('user')) {
            $query->whereHas('user', function ($q) use ($request) {
                $q->where('first_name', 'like', '%' . $request->user . '%')
                  ->orWhere('last_name', 'like', '%' . $request->user . '%')
                  ->orWhere('email', 'like', '%' . $request->user . '%');
            });
        }

        if ($request->filled('currency')) {
            $query->whereHas('currency', function ($q) use ($request) {
                $q->where('code', 'like', '%' . $request->currency . '%');
            });
        }

        $wallets = $query->paginate(20);

        return view('backend.bitgo_wallets.index', compact('wallets'));
    }

    /**
     * Export BitGo wallets to Excel.
     */
    public function export(Request $request)
    {
        return Excel::download(new BitGoWalletsExport($request->query()), 'bitgo_wallets.xlsx');
    }
}
