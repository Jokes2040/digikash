<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\BitGoWebhookEvent;
use App\Models\BitGoAuditLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BitGoWebhooksController extends Controller
{
    /**
     * Display webhook events.
     */
    public function index(Request $request)
    {
        $query = BitGoWebhookEvent::with('user');

        // Apply filters
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('event_type')) {
            $query->where('event_type', $request->event_type);
        }

        if ($request->filled('user_id')) {
            $query->where('user_id', $request->user_id);
        }

        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }

        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        $webhooks = $query->latest()->paginate(20);

        return view('backend.bitgo.webhooks.index', compact('webhooks'));
    }

    /**
     * Show webhook details.
     */
    public function show(BitGoWebhookEvent $webhook)
    {
        return view('backend.bitgo.webhooks.show', compact('webhook'));
    }

    /**
     * Retry failed webhook.
     */
    public function retry(BitGoWebhookEvent $webhook)
    {
        if ($webhook->status !== 'failed') {
            return back()->withErrors('Only failed webhooks can be retried.');
        }

        // Here you would implement retry logic
        // For now, just mark as pending
        $webhook->update(['status' => 'pending']);

        // Log audit
        BitGoAuditLog::create([
            'admin_id' => Auth::id(),
            'environment' => 'production', // or get from settings
            'action' => 'webhook_retry',
            'old_values' => ['status' => 'failed'],
            'new_values' => ['status' => 'pending'],
            'changed_at' => now(),
        ]);

        return back()->with('success', 'Webhook queued for retry.');
    }
}
