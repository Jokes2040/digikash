<?php

namespace App\Http\Controllers;

use App\Models\BitGoWallet;
use App\Models\BitGoWebhookEvent;
use App\Models\Transaction;
use App\Enums\TrxType;
use App\Enums\TrxStatus;
use App\Enums\AmountFlow;
use App\Services\BitGoService;
use App\Services\WalletService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class DepositWebhookController extends Controller
{
    protected BitGoService $bitGoService;
    protected WalletService $walletService;

    public function __construct(BitGoService $bitGoService, WalletService $walletService)
    {
        $this->bitGoService = $bitGoService;
        $this->walletService = $walletService;
    }

    /**
     * Handle BitGo deposit webhook.
     */
    public function handle(Request $request)
    {
        $payload = $request->getContent();
        $signature = $request->header('X-BitGo-Signature');

        // Verify webhook signature
        if (!$this->bitGoService->verifyWebhookSignature($payload, $signature)) {
            Log::warning('Invalid BitGo webhook signature');
            return response()->json(['error' => 'Invalid signature'], 401);
        }

        $data = json_decode($payload, true);

        // Store webhook event
        $webhookEvent = BitGoWebhookEvent::create([
            'user_id' => null, // Will be set after finding wallet
            'event_type' => $data['type'] ?? 'unknown',
            'payload' => $data,
            'status' => 'pending',
        ]);

        // Process only transfer events (deposits)
        if ($data['type'] !== 'transfer' || $data['state'] !== 'confirmed') {
            $webhookEvent->markAsProcessed();
            return response()->json(['status' => 'ignored']);
        }

        $bitgoWalletId = $data['wallet'];
        $bitgoTxId = $data['transfer']['id'];
        $amount = $data['transfer']['value'] / 100000000; // Convert from satoshis
        $currencyCode = $data['coin'];

        // Find the BitGoWallet
        $bitGoWallet = BitGoWallet::byBitGoWalletId($bitgoWalletId)->first();
        if (!$bitGoWallet) {
            Log::error('BitGo wallet not found', ['bitgo_wallet_id' => $bitgoWalletId]);
            return response()->json(['error' => 'Wallet not found'], 404);
        }

        // Idempotent processing: Check if transaction already exists
        $existingTransaction = Transaction::where('bitgo_tx_id', $bitgoTxId)->first();
        if ($existingTransaction) {
            return response()->json(['status' => 'already_processed']);
        }

        DB::transaction(function () use ($bitGoWallet, $bitgoTxId, $amount, $currencyCode, $webhookEvent) {
            // Credit the user's wallet
            $wallet = $bitGoWallet->user->wallets()->where('currency_id', $bitGoWallet->currency_id)->first();
            if ($wallet) {
                $this->walletService->addMoney($wallet, $amount);
            }

            // Create transaction record
            Transaction::create([
                'user_id' => $bitGoWallet->user_id,
                'trx_type' => TrxType::DEPOSIT,
                'description' => "Crypto deposit via BitGo",
                'amount' => $amount,
                'amount_flow' => AmountFlow::PLUS,
                'currency' => $currencyCode,
                'net_amount' => $amount,
                'wallet_reference' => $wallet->uuid ?? null,
                'bitgo_tx_id' => $bitgoTxId,
                'status' => TrxStatus::COMPLETED,
            ]);

            // Mark webhook as processed
            $webhookEvent->markAsProcessed();
        });

        Log::info('Deposit processed', ['bitgo_tx_id' => $bitgoTxId, 'amount' => $amount]);

        return response()->json(['status' => 'processed']);
    }
}
