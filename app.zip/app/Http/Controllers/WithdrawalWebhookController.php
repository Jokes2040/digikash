<?php

namespace App\Http\Controllers;

use App\Services\WithdrawalService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class WithdrawalWebhookController extends Controller
{
    protected WithdrawalService $withdrawalService;

    public function __construct(WithdrawalService $withdrawalService)
    {
        $this->withdrawalService = $withdrawalService;
    }

    /**
     * Handle BitGo withdrawal webhook.
     */
    public function handle(Request $request)
    {
        try {
            $payload = $request->all();
            Log::info('BitGo withdrawal webhook received', ['payload' => $payload]);

            // Validate webhook signature if needed
            // This would depend on BitGo's webhook signing mechanism

            if (isset($payload['transfer']) && isset($payload['transfer']['id'])) {
                $bitgoTxId = $payload['transfer']['id'];
                $status = $payload['transfer']['state'] ?? 'unknown';

                // Map BitGo status to our status
                $mappedStatus = match ($status) {
                    'confirmed' => 'confirmed',
                    'failed' => 'failed',
                    default => 'pending'
                };

                $this->withdrawalService->handleWithdrawalConfirmation($bitgoTxId, $mappedStatus);

                return response()->json(['status' => 'ok']);
            }

            Log::warning('Invalid withdrawal webhook payload', ['payload' => $payload]);
            return response()->json(['error' => 'Invalid payload'], 400);

        } catch (\Exception $e) {
            Log::error('Error processing withdrawal webhook', [
                'error' => $e->getMessage(),
                'payload' => $request->all()
            ]);

            return response()->json(['error' => 'Internal server error'], 500);
        }
    }
}
