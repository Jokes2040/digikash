<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;

class BusinessesController extends Controller
{
    //
}
