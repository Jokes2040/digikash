<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class BitGoAuditLog extends Model
{
    use HasFactory;

    protected $table = 'bitgo_audit_logs';

    protected $fillable = [
        'admin_id',
        'environment',
        'action',
        'old_values',
        'new_values',
        'changed_at',
    ];

    protected $casts = [
        'old_values' => 'array',
        'new_values' => 'array',
        'changed_at' => 'datetime',
    ];

    /**
     * Get the admin who made the change.
     */
    public function admin(): BelongsTo
    {
        return $this->belongsTo(Admin::class);
    }
}
