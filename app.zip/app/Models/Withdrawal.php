<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Withdrawal extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'currency',
        'amount',
        'destination_address',
        'status',
        'idempotency_key',
        'bitgo_tx_id',
        'tx_hash',
        'signed_tx',
        'broadcast_attempts',
    ];

    protected $casts = [
        'amount' => 'decimal:8',
        'broadcast_attempts' => 'integer',
    ];

    /**
     * Relationship to User.
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Scope for pending withdrawals.
     */
    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    /**
     * Scope for confirmed withdrawals.
     */
    public function scopeConfirmed($query)
    {
        return $query->where('status', 'confirmed');
    }

    /**
     * Scope for failed withdrawals.
     */
    public function scopeFailed($query)
    {
        return $query->where('status', 'failed');
    }
}
