<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Crypt;

class BitGoSetting extends Model
{
    use HasFactory;

    protected $table = 'bitgo_settings';

    protected $fillable = [
        'environment',
        'api_key',
        'webhook_secret',
        'wallet_passphrase',
    ];

    protected $casts = [
        'api_key' => 'encrypted',
        'webhook_secret' => 'encrypted',
        'wallet_passphrase' => 'encrypted',
    ];

    /**
     * Get the masked API key.
     */
    public function getMaskedApiKeyAttribute()
    {
        return $this->maskValue($this->api_key);
    }

    /**
     * Get the masked webhook secret.
     */
    public function getMaskedWebhookSecretAttribute()
    {
        return $this->maskValue($this->webhook_secret);
    }

    /**
     * Get the masked wallet passphrase.
     */
    public function getMaskedWalletPassphraseAttribute()
    {
        return $this->maskValue($this->wallet_passphrase);
    }

    /**
     * Mask a value for display.
     */
    protected function maskValue($value)
    {
        if (!$value) return null;
        $length = strlen($value);
        if ($length <= 4) return str_repeat('*', $length);
        return substr($value, 0, 4) . str_repeat('*', $length - 4);
    }

    /**
     * Get settings for a specific environment.
     */
    public static function forEnvironment($environment = 'production')
    {
        return static::where('environment', $environment)->first();
    }
}
