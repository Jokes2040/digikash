<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class BitGoWallet extends Model
{
    use HasFactory;

    protected $table = 'bitgo_wallets';

    protected $fillable = [
        'user_id',
        'currency_id',
        'bitgo_wallet_id',
        'bitgo_address',
    ];

    protected $casts = [
        'user_id'     => 'integer',
        'currency_id' => 'integer',
    ];

    /**
     * Relationship to User.
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Relationship to Currency.
     */
    public function currency(): BelongsTo
    {
        return $this->belongsTo(Currency::class);
    }

    /**
     * Scope to find by BitGo wallet ID.
     */
    public function scopeByBitGoWalletId($query, string $bitgoWalletId)
    {
        return $query->where('bitgo_wallet_id', $bitgoWalletId);
    }
}
