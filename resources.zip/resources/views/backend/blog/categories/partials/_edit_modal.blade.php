<div class="modal fade" id="edit-category-modal" tabindex="-1" aria-labelledby="editCategoryLabel" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">{{ __('Edit Category') }}</h5>
				<button type="button" class="btn-close" data-coreui-dismiss="modal" aria-label="Close"></button>
			</div>
			
			<div class="modal-body" id="edit-category-form-append">
				{{-- Form will be loaded here by AJAX --}}
			</div>
		</div>
	</div>
</div>
