<div class="crancy-wc__banner">
	<div class="crancy-wc__logo">
		<a href="{{ route('admin.dashboard') }}"><img src="{{ asset(setting('light_logo')) }}" alt="#"></a>
	</div>
	<img src="{{ asset(setting('login_banner')) }}" alt="#">
</div>