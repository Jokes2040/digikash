<div class="crancy-wc__footer--top">
	<p class="crancy-wc__footer--copyright">{{ setting('copyright_text') }} </p>
</div>