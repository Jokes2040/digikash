@extends('backend.layouts.app')

@section('title', 'Create Custodial Wallet')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title mb-0">Create Custodial Wallet</h4>
                    <div class="card-tools">
                        <a href="{{ route('admin.custodial-wallets.index') }}" class="btn btn-secondary btn-sm">Back to List</a>
                    </div>
                </div>
                <div class="card-body">
                    <form action="{{ route('admin.custodial-wallets.store') }}" method="POST">
                        @csrf
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="form-group">
                            <label for="currency">Currency</label>
                            <select class="form-control" id="currency" name="currency" required>
                                <option value="">Select Currency</option>
                                <option value="BTC">BTC</option>
                                <option value="ETH">ETH</option>
                                <option value="USDT-TRC20">USDT-TRC20</option>
                                <option value="USDT-ERC20">USDT-ERC20</option>
                                <option value="SOL">SOL</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="chain">Chain</label>
                            <select class="form-control" id="chain" name="chain" required>
                                <option value="">Select Chain</option>
                                <option value="BTC">BTC</option>
                                <option value="ETH">ETH</option>
                                <option value="TRON">TRON</option>
                                <option value="SOL">SOL</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="rpc_url">RPC URL</label>
                            <input type="url" class="form-control" id="rpc_url" name="rpc_url" required>
                        </div>
                        <div class="form-group">
                            <label for="hot_wallet_address">Hot Wallet Address</label>
                            <input type="text" class="form-control" id="hot_wallet_address" name="hot_wallet_address" required>
                        </div>
                        <div class="form-group">
                            <label for="encrypted_signing_key">Encrypted Signing Key</label>
                            <input type="text" class="form-control" id="encrypted_signing_key" name="encrypted_signing_key" required>
                        </div>
                        <div class="form-group">
                            <label for="enabled">Enabled</label>
                            <input type="checkbox" id="enabled" name="enabled" value="1">
                        </div>
                        <button type="submit" class="btn btn-primary">Create Wallet</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
