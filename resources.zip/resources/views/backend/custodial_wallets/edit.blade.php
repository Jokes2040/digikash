@extends('backend.layouts.app')

@section('title', 'Edit Custodial Wallet')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title mb-0">Edit Custodial Wallet</h4>
                </div>
                <div class="card-body">
                    <form action="{{ route('admin.custodial-wallets.update', $wallet) }}" method="POST">
                        @csrf
                        @method('PUT')
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="rpc_url">RPC URL</label>
                                    <input type="url" name="rpc_url" id="rpc_url" class="form-control" value="{{ $wallet->rpc_url }}" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="hot_wallet_address">Hot Wallet Address</label>
                                    <input type="text" name="hot_wallet_address" id="hot_wallet_address" class="form-control" value="{{ $wallet->hot_wallet_address }}" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="enabled">Enabled</label>
                                    <input type="checkbox" name="enabled" id="enabled" value="1" {{ $wallet->enabled ? 'checked' : '' }}>
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Update Wallet</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
