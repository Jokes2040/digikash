@extends('backend.layouts.app')

@section('title', 'Custodial Wallets')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title mb-0">Custodial Wallets</h4>
                    <div class="card-tools">
                        <a href="{{ route('admin.custodial-wallets.create') }}" class="btn btn-primary btn-sm">Add Wallet</a>
                        <button id="refresh-all" class="btn btn-info btn-sm">Refresh All</button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Currency</th>
                                    <th>Chain</th>
                                    <th>Total</th>
                                    <th>Available</th>
                                    <th>Reserved</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($wallets as $wallet)
                                <tr>
                                    <td>{{ $wallet->name }}</td>
                                    <td>{{ $wallet->currency }}</td>
                                    <td>{{ $wallet->chain }}</td>
                                    <td id="total-{{ $wallet->id }}">{{ number_format($wallet->balance->total ?? 0, 8) }}</td>
                                    <td id="available-{{ $wallet->id }}">{{ number_format($wallet->balance->available ?? 0, 8) }}</td>
                                    <td id="reserved-{{ $wallet->id }}">{{ number_format($wallet->balance->reserved ?? 0, 8) }}</td>
                                    <td>
                                        <button class="btn btn-sm btn-info refresh-btn" data-id="{{ $wallet->id }}">Refresh</button>
                                        <a href="{{ route('admin.custodial-wallets.edit', $wallet->id) }}" class="btn btn-sm btn-warning">Edit</a>
                                        <a href="{{ route('admin.custodial-wallets.deposit', $wallet->id) }}" class="btn btn-sm btn-success">Deposit</a>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="7" class="text-center">No custodial wallets found.</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('.refresh-btn').on('click', function() {
        var walletId = $(this).data('id');
        refreshBalance(walletId);
    });

    $('#refresh-all').on('click', function() {
        @foreach($wallets as $wallet)
            refreshBalance({{ $wallet->id }});
        @endforeach
    });

    function refreshBalance(walletId) {
        $.post('{{ route("admin.custodial-wallets.refresh", ":id") }}'.replace(':id', walletId), {
            _token: '{{ csrf_token() }}'
        }).done(function(data) {
            $('#total-' + walletId).text(data.total);
            $('#available-' + walletId).text(data.available);
            $('#reserved-' + walletId).text(data.reserved);
        }).fail(function() {
            alert('Failed to refresh balance');
        });
    }
});
</script>
@endsection
