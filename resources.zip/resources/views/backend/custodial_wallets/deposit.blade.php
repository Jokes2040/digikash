@extends('backend.layouts.app')

@section('title', 'Deposit to Custodial Wallet')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title mb-0">Deposit to {{ $wallet->name }}</h4>
                </div>
                <div class="card-body">
                    <form action="{{ route('admin.custodial-wallets.deposit.store') }}" method="POST">
                        @csrf
                        <input type="hidden" name="wallet_id" value="{{ $wallet->id }}">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="amount">Amount</label>
                                    <input type="number" step="any" name="amount" id="amount" class="form-control" required value="0" placeholder="Enter amount" min="0">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="notes">Notes</label>
                                    <textarea name="notes" id="notes" class="form-control"></textarea>
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success">Record Deposit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
