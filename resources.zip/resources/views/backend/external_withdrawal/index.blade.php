@extends('backend.layouts.app')

@section('title', 'External Withdrawals Overview')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title mb-0">External Withdrawals Overview</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="card bg-primary text-white">
                                <div class="card-body">
                                    <h5 class="card-title">Pending Withdrawals</h5>
                                    <h2>{{ $totalWithdrawals }}</h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card bg-success text-white">
                                <div class="card-body">
                                    <h5 class="card-title">Completed Withdrawals</h5>
                                    <h2>{{ $completedWithdrawals }}</h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card bg-danger text-white">
                                <div class="card-body">
                                    <h5 class="card-title">Failed Withdrawals</h5>
                                    <h2>{{ $failedWithdrawals }}</h2>
                                </div>
                            </div>
                        </div>
                    </div>

                    <hr>

                    <h5>Pending Withdrawal Queue</h5>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>User</th>
                                    <th>Currency</th>
                                    <th>Amount</th>
                                    <th>Destination</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($pendingWithdrawals ?? [] as $withdrawal)
                                <tr>
                                    <td>{{ $withdrawal->id }}</td>
                                    <td>{{ $withdrawal->user->name ?? 'N/A' }}</td>
                                    <td>{{ $withdrawal->currency }}</td>
                                    <td>{{ number_format($withdrawal->amount, 8) }}</td>
                                    <td>{{ Str::limit($withdrawal->destination_address, 20) }}</td>
                                    <td>
                                        <span class="badge badge-{{ $withdrawal->status === 'pending' ? 'warning' : 'info' }}">
                                            {{ ucfirst($withdrawal->status) }}
                                        </span>
                                    </td>
                                    <td>{{ $withdrawal->created_at->diffForHumans() }}</td>
                                    <td>
                                        <a href="{{ route('admin.external-withdrawal.history') }}?search={{ $withdrawal->trx_id }}" class="btn btn-sm btn-info">View Details</a>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="8" class="text-center">No pending withdrawals in queue.</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
