@extends('backend.layouts.app')

@section('title', 'Blockchain Settings')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title mb-0">Blockchain Settings</h4>
                </div>
                <div class="card-body">
                    <form method="POST" action="{{ route('admin.external-withdrawal.blockchain-settings.update') }}">
                        @csrf
                        @foreach($settings as $setting)
                        <div class="card mb-3">
                            <div class="card-header">
                                <h5>{{ $setting->chain_name }}</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>RPC URL</label>
                                            <input type="text" name="settings[{{ $setting->chain_name }}][rpc_url]" class="form-control" value="{{ $setting->rpc_url }}" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Hot Wallet Public Address</label>
                                            <input type="text" name="settings[{{ $setting->chain_name }}][hot_wallet_public_address]" class="form-control" value="{{ $setting->hot_wallet_public_address }}" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Encrypted Signing Key</label>
                                            <input type="password" name="settings[{{ $setting->chain_name }}][encrypted_signing_key]" class="form-control" placeholder="Leave blank to keep current">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Enabled</label>
                                            <select name="settings[{{ $setting->chain_name }}][enabled]" class="form-control">
                                                <option value="1" {{ $setting->enabled ? 'selected' : '' }}>Yes</option>
                                                <option value="0" {{ !$setting->enabled ? 'selected' : '' }}>No</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Fixed Fee</label>
                                            <input type="number" step="0.00000001" name="settings[{{ $setting->chain_name }}][fee_fixed]" class="form-control" value="{{ $setting->fee_fixed }}">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Fee Percent</label>
                                            <input type="number" step="0.01" name="settings[{{ $setting->chain_name }}][fee_percent]" class="form-control" value="{{ $setting->fee_percent }}">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Min Withdrawal</label>
                                            <input type="number" step="0.00000001" name="settings[{{ $setting->chain_name }}][min_withdrawal]" class="form-control" value="{{ $setting->min_withdrawal }}">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Max Withdrawal</label>
                                            <input type="number" step="0.00000001" name="settings[{{ $setting->chain_name }}][max_withdrawal]" class="form-control" value="{{ $setting->max_withdrawal }}">
                                        </div>
                                    </div>
                                </div>
                                <input type="hidden" name="settings[{{ $setting->chain_name }}][chain_name]" value="{{ $setting->chain_name }}">
                            </div>
                        </div>
                        @endforeach
                        <button type="submit" class="btn btn-primary">Update Settings</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
