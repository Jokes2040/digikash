@extends('backend.layouts.app')

@section('title', 'External Withdrawal History')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title mb-0">External Withdrawal History</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>User</th>
                                    <th>Currency</th>
                                    <th>Amount</th>
                                    <th>Destination Address</th>
                                    <th>Status</th>
                                    <th>Tx Hash</th>
                                    <th>Created At</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($withdrawals as $withdrawal)
                                <tr>
                                    <td>{{ $withdrawal->id }}</td>
                                    <td>{{ $withdrawal->user->first_name ?? 'N/A' }} {{ $withdrawal->user->last_name ?? '' }}</td>
                                    <td>{{ $withdrawal->currency }}</td>
                                    <td>{{ number_format($withdrawal->amount, 8) }}</td>
                                    <td>{{ Str::limit($withdrawal->destination_address, 20) }}</td>
                                    <td>
                                        <span class="badge badge-{{ $withdrawal->status === 'confirmed' ? 'success' : ($withdrawal->status === 'failed' ? 'danger' : 'warning') }}">
                                            {{ ucfirst($withdrawal->status) }}
                                        </span>
                                    </td>
                                    <td>{{ $withdrawal->tx_hash ? Str::limit($withdrawal->tx_hash, 20) : 'N/A' }}</td>
                                    <td>{{ $withdrawal->created_at->format('M d Y H:i') }}</td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="8" class="text-center">No withdrawals found.</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                    {{ $withdrawals->links() }}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
