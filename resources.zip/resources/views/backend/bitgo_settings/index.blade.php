@extends('backend.layouts.app')
@section('title')
    {{ __('BitGo Settings') }}
@endsection
@section('content')
    <div class="card px-3 py-3">
        <h4>{{ __('BitGo API Configuration') }}</h4>
        <p>{{ __('Manage BitGo API credentials securely. All values are encrypted in the database.') }}</p>

        @if(session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        @if($errors->any())
            <div class="alert alert-danger">
                <ul class="mb-0">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        @if($setting)
            <form action="{{ route('admin.bitgo.settings.update', ['environment' => $setting->environment]) }}" method="POST">
                @csrf
                @method('PUT')
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="api_key" class="form-label">{{ __('API Key') }}</label>
                            <input type="password" class="form-control @error('api_key') is-invalid @enderror" id="api_key" name="api_key" value="{{ old('api_key') }}" placeholder="Enter new API key to update">
                            @error('api_key')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <small class="text-muted">{{ __('Current: ') . $setting->masked_api_key }}</small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="webhook_secret" class="form-label">{{ __('Webhook Secret') }}</label>
                            <input type="password" class="form-control @error('webhook_secret') is-invalid @enderror" id="webhook_secret" name="webhook_secret" value="{{ old('webhook_secret') }}" placeholder="Enter new webhook secret to update">
                            @error('webhook_secret')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <small class="text-muted">{{ __('Current: ') . $setting->masked_webhook_secret }}</small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="wallet_passphrase" class="form-label">{{ __('Wallet Passphrase') }}</label>
                            <input type="password" class="form-control @error('wallet_passphrase') is-invalid @enderror" id="wallet_passphrase" name="wallet_passphrase" value="{{ old('wallet_passphrase') }}" placeholder="Enter new wallet passphrase to update">
                            @error('wallet_passphrase')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <small class="text-muted">{{ __('Current: ') . $setting->masked_wallet_passphrase }}</small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="environment" class="form-label">{{ __('Environment') }}</label>
                            <select class="form-select @error('environment') is-invalid @enderror" id="environment" name="environment">
                                <option value="production" {{ $setting->environment == 'production' ? 'selected' : '' }}>Production</option>
                                <option value="staging" {{ $setting->environment == 'staging' ? 'selected' : '' }}>Staging</option>
                            </select>
                            @error('environment')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">{{ __('Update Settings') }}</button>
            </form>

            <hr>
            <h5>{{ __('Recent Audit Logs') }}</h5>
            @if($auditLogs->count() > 0)
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>{{ __('Admin') }}</th>
                            <th>{{ __('Action') }}</th>
                            <th>{{ __('Environment') }}</th>
                            <th>{{ __('Date') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($auditLogs as $log)
                            <tr>
                                <td>{{ $log->admin->name ?? 'Unknown' }}</td>
                                <td>{{ ucfirst($log->action) }}</td>
                                <td>{{ ucfirst($log->environment) }}</td>
                                <td>{{ $log->created_at->format('Y-m-d H:i') }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            @else
                <p class="text-muted">{{ __('No audit logs found.') }}</p>
            @endif
        @else
            <div class="alert alert-warning">
                {{ __('No BitGo settings configured yet. Please set them up below.') }}
            </div>
            <form action="{{ route('admin.bitgo.settings.update', ['environment' => 'production']) }}" method="POST">
                @csrf
                @method('PUT')
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="api_key" class="form-label">{{ __('API Key') }} <span class="text-danger">*</span></label>
                            <input type="password" class="form-control @error('api_key') is-invalid @enderror" id="api_key" name="api_key" value="{{ old('api_key') }}" required>
                            @error('api_key')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="webhook_secret" class="form-label">{{ __('Webhook Secret') }} <span class="text-danger">*</span></label>
                            <input type="password" class="form-control @error('webhook_secret') is-invalid @enderror" id="webhook_secret" name="webhook_secret" value="{{ old('webhook_secret') }}" required>
                            @error('webhook_secret')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="wallet_passphrase" class="form-label">{{ __('Wallet Passphrase') }} <span class="text-danger">*</span></label>
                            <input type="password" class="form-control @error('wallet_passphrase') is-invalid @enderror" id="wallet_passphrase" name="wallet_passphrase" value="{{ old('wallet_passphrase') }}" required>
                            @error('wallet_passphrase')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="environment" class="form-label">{{ __('Environment') }} <span class="text-danger">*</span></label>
                            <select class="form-select @error('environment') is-invalid @enderror" id="environment" name="environment" required>
                                <option value="production" {{ old('environment') == 'production' ? 'selected' : '' }}>Production</option>
                                <option value="staging" {{ old('environment') == 'staging' ? 'selected' : '' }}>Staging</option>
                            </select>
                            @error('environment')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">{{ __('Save Settings') }}</button>
            </form>
        @endif
    </div>
@endsection
