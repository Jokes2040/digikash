<div class="modal fade" id="edit-footer-section-modal" tabindex="-1" aria-labelledby="editFooterSectionLabel" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered modal-md">
		<div class="modal-content shadow-sm rounded-3">
			<div class="modal-header">
				<h5 class="modal-title">{{ __('Update Footer Section') }}</h5>
				<button type="button" class="btn-close" data-coreui-dismiss="modal" aria-label="Close"></button>
			</div>
			
			<div class="modal-body" id="edit-footer-section-data">
			
			</div>
		</div>
	</div>
</div>
