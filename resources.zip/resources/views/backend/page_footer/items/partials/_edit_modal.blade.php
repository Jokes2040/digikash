<div class="modal fade" id="edit-footer-item-modal" tabindex="-1" aria-labelledby="editFooterItemLabel" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content shadow-sm rounded-3">
			<div class="modal-header">
				<h5 class="modal-title" id="editFooterItemLabel">{{ __('Edit Footer Item') }}</h5>
				<button type="button" class="btn-close" data-coreui-dismiss="modal" aria-label="Close"></button>
			</div>
			
			<div class="modal-body" id="edit-footer-item-data">
			
			
			</div>
		</div>
	</div>
</div>
