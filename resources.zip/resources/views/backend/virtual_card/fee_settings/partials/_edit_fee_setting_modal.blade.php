<div class="modal fade" id="edit_fee_setting_modal" tabindex="-1" aria-labelledby="editFeeSettingModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editFeeSettingModalLabel">{{ __('Edit Fee Setting') }}</h5>
                <button type="button" class="btn-close" data-coreui-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="edit_fee_setting_data">
                <!-- AJAX content loaded here -->
            </div>
        </div>
    </div>
</div>
