<div class="modal fade" id="manage-virtual-card-modal" aria-hidden="true" aria-labelledby="logoutmodal" tabindex="-1">
	<div class="modal-dialog modal-md modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">{{ __('Update Virtual Card Provider') }}</h5>
				<button type="button" class="btn-close" data-coreui-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body virtual-card-form-edit" id="manage-virtual-card-data">
			
			</div>
		</div>
	</div>
</div>
