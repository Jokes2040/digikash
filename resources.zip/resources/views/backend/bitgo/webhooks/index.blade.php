@extends('backend.layouts.app')
@section('title')
    {{ __('BitGo Webhooks') }}
@endsection
@section('content')
    <div class="container-fluid">
        <!-- Page Header -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="mb-1">{{ __('Webhook Monitoring') }}</h4>
                        <p class="text-muted mb-0">{{ __('Monitor and manage BitGo webhook events') }}</p>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="button" class="btn btn-outline-primary" onclick="refreshPage()">
                            <i class="fas fa-sync-alt"></i> {{ __('Refresh') }}
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-3">
                                <label class="form-label">{{ __('Status') }}</label>
                                <select name="status" class="form-select">
                                    <option value="">{{ __('All Status') }}</option>
                                    <option value="pending" {{ request('status') === 'pending' ? 'selected' : '' }}>{{ __('Pending') }}</option>
                                    <option value="processed" {{ request('status') === 'processed' ? 'selected' : '' }}>{{ __('Processed') }}</option>
                                    <option value="failed" {{ request('status') === 'failed' ? 'selected' : '' }}>{{ __('Failed') }}</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">{{ __('Event Type') }}</label>
                                <select name="event_type" class="form-select">
                                    <option value="">{{ __('All Types') }}</option>
                                    <option value="transfer" {{ request('event_type') === 'transfer' ? 'selected' : '' }}>{{ __('Transfer') }}</option>
                                    <option value="address_confirmation" {{ request('event_type') === 'address_confirmation' ? 'selected' : '' }}>{{ __('Address Confirmation') }}</option>
                                    <option value="transaction" {{ request('event_type') === 'transaction' ? 'selected' : '' }}>{{ __('Transaction') }}</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">{{ __('User ID') }}</label>
                                <input type="text" name="user_id" class="form-control" value="{{ request('user_id') }}" placeholder="{{ __('Enter User ID') }}">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">{{ __('Date From') }}</label>
                                <input type="date" name="date_from" class="form-control" value="{{ request('date_from') }}">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">{{ __('Date To') }}</label>
                                <input type="date" name="date_to" class="form-control" value="{{ request('date_to') }}">
                            </div>
                            <div class="col-md-3 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary me-2">
                                    <i class="fas fa-filter"></i> {{ __('Filter') }}
                                </button>
                                <a href="{{ route('admin.bitgo.webhooks.index') }}" class="btn btn-outline-secondary">
                                    <i class="fas fa-times"></i> {{ __('Clear') }}
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Webhooks Table -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body p-0">
                        @if($webhooks->count() > 0)
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>{{ __('ID') }}</th>
                                            <th>{{ __('Event Type') }}</th>
                                            <th>{{ __('User') }}</th>
                                            <th>{{ __('Status') }}</th>
                                            <th>{{ __('Processed At') }}</th>
                                            <th>{{ __('Created') }}</th>
                                            <th>{{ __('Actions') }}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($webhooks as $webhook)
                                            <tr>
                                                <td>{{ $webhook->id }}</td>
                                                <td>
                                                    <span class="badge bg-info">{{ ucfirst($webhook->event_type) }}</span>
                                                </td>
                                                <td>
                                                    @if($webhook->user)
                                                        <div class="d-flex align-items-center">
                                                            <div class="avatar avatar-xs me-2">
                                                                <span class="avatar-initial rounded-circle bg-primary">
                                                                    {{ substr($webhook->user->name, 0, 1) }}
                                                                </span>
                                                            </div>
                                                            {{ $webhook->user->name }}
                                                        </div>
                                                    @else
                                                        <span class="text-muted">{{ __('System') }}</span>
                                                    @endif
                                                </td>
                                                <td>
                                                    <span class="badge bg-{{ $webhook->status === 'processed' ? 'success' : ($webhook->status === 'failed' ? 'danger' : 'warning') }}">
                                                        {{ ucfirst($webhook->status) }}
                                                    </span>
                                                </td>
                                                <td>
                                                    @if($webhook->processed_at)
                                                        {{ $webhook->processed_at->format('M d, H:i:s') }}
                                                    @else
                                                        <span class="text-muted">-</span>
                                                    @endif
                                                </td>
                                                <td>{{ $webhook->created_at->format('M d, H:i:s') }}</td>
                                                <td>
                                                    <div class="btn-group" role="group">
                                                        <a href="{{ route('admin.bitgo.webhooks.show', $webhook) }}" class="btn btn-sm btn-outline-primary">
                                                            <i class="fas fa-eye"></i>
                                                        </a>
                                                        @if($webhook->status === 'failed')
                                                            <form method="POST" action="{{ route('admin.bitgo.webhooks.retry', $webhook) }}" class="d-inline">
                                                                @csrf
                                                                <button type="submit" class="btn btn-sm btn-outline-warning" onclick="return confirm('{{ __('Retry this webhook?') }}')">
                                                                    <i class="fas fa-redo"></i>
                                                                </button>
                                                            </form>
                                                        @endif
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>

                            <!-- Pagination -->
                            <div class="card-footer">
                                {{ $webhooks->appends(request()->query())->links() }}
                            </div>
                        @else
                            <div class="text-center py-5">
                                <i class="fas fa-webhook fa-3x text-muted mb-3"></i>
                                <h6 class="text-muted">{{ __('No webhook events found') }}</h6>
                                <p class="text-muted">{{ __('Webhook events will appear here as they are received from BitGo') }}</p>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function refreshPage() {
            location.reload();
        }
    </script>
@endsection
