@extends('backend.layouts.app')
@section('title')
    {{ __('BitGo Dashboard') }}
@endsection
@section('content')
    <div class="container-fluid">
        <!-- Page Header -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="mb-1">{{ __('BitGo Management Dashboard') }}</h4>
                        <p class="text-muted mb-0">{{ __('Monitor and manage your BitGo integration') }}</p>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="button" class="btn btn-outline-primary" onclick="refreshDashboard()">
                            <i class="fas fa-sync-alt"></i> {{ __('Refresh') }}
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="row mb-4">
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="flex-shrink-0">
                                <div class="avatar avatar-sm bg-primary rounded">
                                    <i class="fas fa-wallet text-white"></i>
                                </div>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h6 class="mb-1">{{ __('Active Wallets') }}</h6>
                                <h4 class="mb-0">{{ $walletSummary->sum('wallet_count') }}</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="flex-shrink-0">
                                <div class="avatar avatar-sm bg-success rounded">
                                    <i class="fas fa-arrow-down text-white"></i>
                                </div>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h6 class="mb-1">{{ __('Deposits (30d)') }}</h6>
                                <h4 class="mb-0">{{ number_format($transactionStats['deposits']) }}</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="flex-shrink-0">
                                <div class="avatar avatar-sm bg-info rounded">
                                    <i class="fas fa-arrow-up text-white"></i>
                                </div>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h6 class="mb-1">{{ __('Withdrawals (30d)') }}</h6>
                                <h4 class="mb-0">{{ number_format($transactionStats['withdrawals']) }}</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="flex-shrink-0">
                                <div class="avatar avatar-sm bg-warning rounded">
                                    <i class="fas fa-exclamation-triangle text-white"></i>
                                </div>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h6 class="mb-1">{{ __('Active Alerts') }}</h6>
                                <h4 class="mb-0">{{ $activeAlerts->count() }}</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="row">
            <!-- Recent Transactions -->
            <div class="col-xl-8 mb-4">
                <div class="card h-100">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">{{ __('Recent Transactions') }}</h5>
                        <a href="{{ route('admin.transaction') }}" class="btn btn-sm btn-outline-primary">{{ __('View All') }}</a>
                    </div>
                    <div class="card-body p-0">
                        @if($recentTransactions->count() > 0)
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>{{ __('User') }}</th>
                                            <th>{{ __('Type') }}</th>
                                            <th>{{ __('Amount') }}</th>
                                            <th>{{ __('Currency') }}</th>
                                            <th>{{ __('Status') }}</th>
                                            <th>{{ __('Date') }}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($recentTransactions as $transaction)
                                            <tr>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <div class="avatar avatar-xs me-2">
                                                            <span class="avatar-initial rounded-circle bg-primary">
                                                                {{ substr($transaction->user->name ?? 'N/A', 0, 1) }}
                                                            </span>
                                                        </div>
                                                        {{ $transaction->user->name ?? 'N/A' }}
                                                    </div>
                                                </td>
                                                <td>
                                                    <span class="badge bg-{{ $transaction->trx_type === 'deposit' ? 'success' : 'info' }}">
                                                        {{ ucfirst($transaction->trx_type) }}
                                                    </span>
                                                </td>
                                                <td>{{ number_format($transaction->amount, 8) }}</td>
                                                <td>{{ strtoupper($transaction->currency) }}</td>
                                                <td>
                                                    <span class="badge bg-success">{{ __('Completed') }}</span>
                                                </td>
                                                <td>{{ $transaction->created_at->format('M d, H:i') }}</td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @else
                            <div class="text-center py-5">
                                <i class="fas fa-exchange-alt fa-3x text-muted mb-3"></i>
                                <h6 class="text-muted">{{ __('No recent transactions') }}</h6>
                            </div>
                        @endif
                    </div>
                </div>
            </div>

            <!-- Active Alerts & Recent Webhooks -->
            <div class="col-xl-4">
                <!-- Active Alerts -->
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">{{ __('Active Alerts') }}</h5>
                        <a href="{{ route('admin.bitgo.alerts.index') }}" class="btn btn-sm btn-outline-danger">{{ __('View All') }}</a>
                    </div>
                    <div class="card-body p-0">
                        @if($activeAlerts->count() > 0)
                            <div class="list-group list-group-flush">
                                @foreach($activeAlerts as $alert)
                                    <div class="list-group-item px-3 py-3">
                                        <div class="d-flex align-items-start">
                                            <div class="flex-shrink-0 me-3">
                                                <span class="badge bg-{{ $alert->severity === 'critical' ? 'danger' : ($alert->severity === 'warning' ? 'warning' : 'info') }} rounded-pill">
                                                    <i class="fas fa-exclamation-{{ $alert->severity === 'critical' ? 'triangle' : 'circle' }}"></i>
                                                </span>
                                            </div>
                                            <div class="flex-grow-1">
                                                <h6 class="mb-1">{{ ucwords(str_replace('_', ' ', $alert->type)) }}</h6>
                                                <p class="mb-1 text-sm text-muted">{{ Str::limit($alert->message, 60) }}</p>
                                                <small class="text-muted">{{ $alert->created_at->diffForHumans() }}</small>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        @else
                            <div class="text-center py-4">
                                <i class="fas fa-check-circle fa-2x text-success mb-2"></i>
                                <h6 class="text-muted">{{ __('No active alerts') }}</h6>
                            </div>
                        @endif
                    </div>
                </div>

                <!-- Recent Webhooks -->
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">{{ __('Recent Webhooks') }}</h5>
                        <a href="{{ route('admin.bitgo.webhooks.index') }}" class="btn btn-sm btn-outline-info">{{ __('View All') }}</a>
                    </div>
                    <div class="card-body p-0">
                        @if($recentWebhooks->count() > 0)
                            <div class="list-group list-group-flush">
                                @foreach($recentWebhooks as $webhook)
                                    <div class="list-group-item px-3 py-3">
                                        <div class="d-flex align-items-start">
                                            <div class="flex-shrink-0 me-3">
                                                <span class="badge bg-{{ $webhook->status === 'processed' ? 'success' : ($webhook->status === 'failed' ? 'danger' : 'warning') }} rounded-pill">
                                                    <i class="fas fa-{{ $webhook->status === 'processed' ? 'check' : ($webhook->status === 'failed' ? 'times' : 'clock') }}"></i>
                                                </span>
                                            </div>
                                            <div class="flex-grow-1">
                                                <h6 class="mb-1">{{ ucfirst($webhook->event_type) }}</h6>
                                                <p class="mb-1 text-sm text-muted">{{ __('User:') }} {{ $webhook->user->name ?? 'System' }}</p>
                                                <small class="text-muted">{{ $webhook->created_at->diffForHumans() }}</small>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        @else
                            <div class="text-center py-4">
                                <i class="fas fa-webhook fa-2x text-muted mb-2"></i>
                                <h6 class="text-muted">{{ __('No recent webhooks') }}</h6>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>

        <!-- Wallet Summary -->
        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">{{ __('Wallet Summary by Currency') }}</h5>
                    </div>
                    <div class="card-body">
                        @if($walletSummary->count() > 0)
                            <div class="row">
                                @foreach($walletSummary as $summary)
                                    <div class="col-md-3 mb-3">
                                        <div class="card bg-light">
                                            <div class="card-body text-center">
                                                <h3 class="mb-1">{{ $summary->wallet_count }}</h3>
                                                <p class="text-muted mb-0">{{ strtoupper($summary->currency->code ?? 'N/A') }}</p>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        @else
                            <div class="text-center py-4">
                                <i class="fas fa-wallet fa-2x text-muted mb-2"></i>
                                <h6 class="text-muted">{{ __('No wallets configured') }}</h6>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function refreshDashboard() {
            location.reload();
        }

        // Auto refresh every 5 minutes
        setInterval(refreshDashboard, 300000);
    </script>
@endsection
