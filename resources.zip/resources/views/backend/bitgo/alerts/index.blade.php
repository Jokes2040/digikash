@extends('backend.layouts.app')
@section('title')
    {{ __('BitGo Alerts') }}
@endsection
@section('content')
    <div class="container-fluid">
        <!-- Page Header -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="mb-1">{{ __('Alert Management') }}</h4>
                        <p class="text-muted mb-0">{{ __('Monitor and manage BitGo alerts') }}</p>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="button" class="btn btn-outline-primary" onclick="refreshPage()">
                            <i class="fas fa-sync-alt"></i> {{ __('Refresh') }}
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-3">
                                <label class="form-label">{{ __('Type') }}</label>
                                <select name="type" class="form-select">
                                    <option value="">{{ __('All Types') }}</option>
                                    <option value="deposit_failure" {{ request('type') === 'deposit_failure' ? 'selected' : '' }}>{{ __('Deposit Failure') }}</option>
                                    <option value="withdrawal_failure" {{ request('type') === 'withdrawal_failure' ? 'selected' : '' }}>{{ __('Withdrawal Failure') }}</option>
                                    <option value="webhook_error" {{ request('type') === 'webhook_error' ? 'selected' : '' }}>{{ __('Webhook Error') }}</option>
                                    <option value="api_connectivity" {{ request('type') === 'api_connectivity' ? 'selected' : '' }}>{{ __('API Connectivity') }}</option>
                                    <option value="suspicious_transaction" {{ request('type') === 'suspicious_transaction' ? 'selected' : '' }}>{{ __('Suspicious Transaction') }}</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">{{ __('Severity') }}</label>
                                <select name="severity" class="form-select">
                                    <option value="">{{ __('All Severities') }}</option>
                                    <option value="info" {{ request('severity') === 'info' ? 'selected' : '' }}>{{ __('Info') }}</option>
                                    <option value="warning" {{ request('severity') === 'warning' ? 'selected' : '' }}>{{ __('Warning') }}</option>
                                    <option value="critical" {{ request('severity') === 'critical' ? 'selected' : '' }}>{{ __('Critical') }}</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">{{ __('Status') }}</label>
                                <select name="status" class="form-select">
                                    <option value="">{{ __('All Status') }}</option>
                                    <option value="active" {{ request('status') === 'active' ? 'selected' : '' }}>{{ __('Active') }}</option>
                                    <option value="resolved" {{ request('status') === 'resolved' ? 'selected' : '' }}>{{ __('Resolved') }}</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">{{ __('User ID') }}</label>
                                <input type="text" name="user_id" class="form-control" value="{{ request('user_id') }}" placeholder="{{ __('Enter User ID') }}">
                            </div>
                            <div class="col-md-3 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary me-2">
                                    <i class="fas fa-filter"></i> {{ __('Filter') }}
                                </button>
                                <a href="{{ route('admin.bitgo.alerts.index') }}" class="btn btn-outline-secondary">
                                    <i class="fas fa-times"></i> {{ __('Clear') }}
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Alerts Table -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body p-0">
                        @if($alerts->count() > 0)
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>{{ __('ID') }}</th>
                                            <th>{{ __('Type') }}</th>
                                            <th>{{ __('Severity') }}</th>
                                            <th>{{ __('Message') }}</th>
                                            <th>{{ __('User') }}</th>
                                            <th>{{ __('Status') }}</th>
                                            <th>{{ __('Created') }}</th>
                                            <th>{{ __('Actions') }}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($alerts as $alert)
                                            <tr class="{{ $alert->resolved_at ? 'table-light' : ($alert->severity === 'critical' ? 'table-danger' : '') }}">
                                                <td>{{ $alert->id }}</td>
                                                <td>
                                                    <span class="badge bg-secondary">{{ ucwords(str_replace('_', ' ', $alert->type)) }}</span>
                                                </td>
                                                <td>
                                                    <span class="badge bg-{{ $alert->severity === 'critical' ? 'danger' : ($alert->severity === 'warning' ? 'warning' : 'info') }}">
                                                        {{ ucfirst($alert->severity) }}
                                                    </span>
                                                </td>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        @if($alert->severity === 'critical')
                                                            <i class="fas fa-exclamation-triangle text-danger me-2"></i>
                                                        @elseif($alert->severity === 'warning')
                                                            <i class="fas fa-exclamation-circle text-warning me-2"></i>
                                                        @else
                                                            <i class="fas fa-info-circle text-info me-2"></i>
                                                        @endif
                                                        <span title="{{ $alert->message }}">{{ Str::limit($alert->message, 50) }}</span>
                                                    </div>
                                                </td>
                                                <td>
                                                    @if($alert->user)
                                                        <div class="d-flex align-items-center">
                                                            <div class="avatar avatar-xs me-2">
                                                                <span class="avatar-initial rounded-circle bg-primary">
                                                                    {{ substr($alert->user->name, 0, 1) }}
                                                                </span>
                                                            </div>
                                                            {{ $alert->user->name }}
                                                        </div>
                                                    @else
                                                        <span class="text-muted">{{ __('System') }}</span>
                                                    @endif
                                                </td>
                                                <td>
                                                    @if($alert->resolved_at)
                                                        <span class="badge bg-success">{{ __('Resolved') }}</span>
                                                    @else
                                                        <span class="badge bg-warning">{{ __('Active') }}</span>
                                                    @endif
                                                </td>
                                                <td>{{ $alert->created_at->format('M d, H:i') }}</td>
                                                <td>
                                                    @if(!$alert->resolved_at)
                                                        <form method="POST" action="{{ route('admin.bitgo.alerts.resolve', $alert) }}" class="d-inline">
                                                            @csrf
                                                            <button type="submit" class="btn btn-sm btn-success" onclick="return confirm('{{ __('Mark this alert as resolved?') }}')">
                                                                <i class="fas fa-check"></i> {{ __('Resolve') }}
                                                            </button>
                                                        </form>
                                                    @else
                                                        <small class="text-muted">{{ __('Resolved') }} {{ $alert->resolved_at->diffForHumans() }}</small>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>

                            <!-- Pagination -->
                            <div class="card-footer">
                                {{ $alerts->appends(request()->query())->links() }}
                            </div>
                        @else
                            <div class="text-center py-5">
                                <i class="fas fa-bell-slash fa-3x text-muted mb-3"></i>
                                <h6 class="text-muted">{{ __('No alerts found') }}</h6>
                                <p class="text-muted">{{ __('Alerts will appear here when issues are detected') }}</p>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function refreshPage() {
            location.reload();
        }
    </script>
@endsection
