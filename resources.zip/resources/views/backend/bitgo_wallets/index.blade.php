@extends('backend.layouts.app')
@section('title')
    {{ __('BitGo Wallets') }}
@endsection
@section('content')
    <div class="card px-3 py-3">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h4>{{ __('BitGo Wallets') }}</h4>
                <p>{{ __('View and manage BitGo wallets associated with users and currencies.') }}</p>
            </div>
            <div>
                <a href="{{ route('admin.bitgo.wallets.export', request()->query()) }}" class="btn btn-success">
                    <i class="fas fa-download"></i> {{ __('Export to Excel') }}
                </a>
            </div>
        </div>

        <!-- Filters -->
        <form method="GET" class="mb-3">
            <div class="row">
                <div class="col-md-3">
                    <input type="text" name="user" class="form-control" placeholder="{{ __('Search by user') }}" value="{{ request('user') }}">
                </div>
                <div class="col-md-3">
                    <input type="text" name="currency" class="form-control" placeholder="{{ __('Currency code') }}" value="{{ request('currency') }}">
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary">{{ __('Filter') }}</button>
                    <a href="{{ route('admin.bitgo.wallets.index') }}" class="btn btn-secondary">{{ __('Clear') }}</a>
                </div>
            </div>
        </form>

        @if($wallets->count() > 0)
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>{{ __('User') }}</th>
                            <th>{{ __('Currency') }}</th>
                            <th>{{ __('BitGo Wallet ID') }}</th>
                            <th>{{ __('Deposit Address') }}</th>
                            <th>{{ __('Created At') }}</th>
                            <th>{{ __('Actions') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($wallets as $wallet)
                            <tr>
                                <td>
                                    @if($wallet->user)
                                        {{ $wallet->user->first_name }} {{ $wallet->user->last_name }}<br>
                                        <small class="text-muted">{{ $wallet->user->email }}</small>
                                    @else
                                        {{ __('Shared Wallet') }}
                                    @endif
                                </td>
                                <td>{{ $wallet->currency->name ?? 'N/A' }} ({{ $wallet->currency->code ?? 'N/A' }})</td>
                                <td><code>{{ Str::limit($wallet->bitgo_wallet_id, 20) }}</code></td>
                                <td>
                                    <code id="address-{{ $wallet->id }}">{{ $wallet->bitgo_address }}</code>
                                    <button class="btn btn-sm btn-outline-primary ms-2 regenerate-btn"
                                            data-wallet-id="{{ $wallet->id }}"
                                            data-old-address="{{ $wallet->bitgo_address }}">
                                        <i class="fas fa-sync"></i>
                                    </button>
                                </td>
                                <td>{{ $wallet->created_at->format('Y-m-d H:i') }}</td>
                                <td>
                                    <button class="btn btn-sm btn-info" onclick="copyToClipboard('{{ $wallet->bitgo_address }}')">
                                        <i class="fas fa-copy"></i>
                                    </button>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            {{ $wallets->appends(request()->query())->links() }}
        @else
            <div class="alert alert-info">
                {{ __('No BitGo wallets found.') }}
            </div>
        @endif
    </div>

    <script>
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(function() {
                // Show success message
                alert('Address copied to clipboard!');
            });
        }

        $(document).ready(function() {
            $('.regenerate-btn').on('click', function() {
                const walletId = $(this).data('wallet-id');
                const oldAddress = $(this).data('old-address');
                const btn = $(this);

                if (confirm('Are you sure you want to regenerate the deposit address? This will create a new address.')) {
                    btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i>');

                    $.ajax({
                        url: '{{ route("admin.bitgo.wallets.index") }}/' + walletId + '/regenerate-address',
                        method: 'POST',
                        data: {
                            _token: '{{ csrf_token() }}',
                            old_address: oldAddress
                        },
                        success: function(response) {
                            if (response.success) {
                                $('#address-' + walletId).text(response.address);
                                btn.data('old-address', response.address);
                                alert('Address regenerated successfully!');
                            } else {
                                alert('Error: ' + response.message);
                            }
                        },
                        error: function(xhr) {
                            alert('Error regenerating address: ' + xhr.responseJSON?.message || 'Unknown error');
                        },
                        complete: function() {
                            btn.prop('disabled', false).html('<i class="fas fa-sync"></i>');
                        }
                    });
                }
            });
        });
    </script>
@endsection
