<footer class="footer px-4">
    <div>{{ setting('copyright_text') }}</div>
    <div class="ms-auto">{{ __('Version') }}: {{ config('app.version') }}</div>
</footer>
