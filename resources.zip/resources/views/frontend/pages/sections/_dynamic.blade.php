<section>
	<div class="container">
		{!! $component->content_data['content'][app()->getLocale()] ?? '' !!}
	</div>
</section>
