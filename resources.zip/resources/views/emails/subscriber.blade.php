<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>{{ $subject }}</title>
</head>
<body>
<p>{!! nl2br(e($messageContent)) !!}</p>
</body>
</html>
