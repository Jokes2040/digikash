<?php

return [
    'failed'   => '',
    'password' => '',
    'throttle' => '',
];
