<?php

return [
    'failed'   => 'The email or password you entered is incorrect. Please try again.',
    'password' => '',
    'throttle' => '',
];
