<?php

return [

    'component_fields' => [

        'section_heading' => [
            'translatable' => true,
            'type'         => 'text',
            'class'        => 'col-md-12',
            'validation'   => 'nullable|string|max:255',
        ],

    ],

];
