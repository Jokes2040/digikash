"use strict";
// Example JS functionality
document.addEventListener("DOMContentLoaded", () => {
  console.log('Custom landing loaded');
});