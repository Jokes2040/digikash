<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides a sane
    | default location for this type of information, which is encrypted
    | at rest.
    |
    */

    'mailgun' => [
        'domain' => env('MAILGUN_DOMAIN'),
        'secret' => env('MAILGUN_SECRET'),
        'endpoint' => env('MAILGUN_ENDPOINT', 'api.mailgun.net'),
        'scheme' => 'https',
    ],

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'twilio' => [
        'sid' => env('TWILIO_SID'),
        'token' => env('TWILIO_TOKEN'),
        'from' => env('TWILIO_FROM'),
    ],

    'stripe' => [
        'model' => env('STRIPE_MODEL', 'User'),
        'key' => env('STRIPE_KEY'),
        'secret' => env('STRIPE_SECRET'),
        'webhook' => [
            'secret' => env('STRIPE_WEBHOOK_SECRET'),
            'tolerance' => env('STRIPE_WEBHOOK_TOLERANCE', 300),
        ],
    ],

    'mollie' => [
        'key' => env('MOLLIE_KEY'),
    ],

    'cryptomus' => [
        'merchant_id' => env('CRYPTOMUS_MERCHANT_ID'),
        'payment_key' => env('CRYPTOMUS_PAYMENT_KEY'),
        'payout_key' => env('CRYPTOMUS_PAYOUT_KEY'),
    ],

    'bitgo' => [
        // Base URLs for different environments
        'base_url' => env('BITGO_BASE_URL', 'https://app.bitgo.com/api/v2'),
        'testnet_base_url' => env('BITGO_TESTNET_BASE_URL', 'https://app.bitgo-test.com/api/v2'),

        // API Keys - Obtain from BitGo Developer Portal
        // Production: https://app.bitgo.com/settings/api-access-tokens
        // Testnet: https://app.bitgo-test.com/settings/api-access-tokens
        'production_api_key' => env('BITGO_PRODUCTION_API_KEY'),
        'testnet_api_key' => env('BITGO_TESTNET_API_KEY'),

        // Webhook Secret - Generate in BitGo Developer Portal
        // Used for HMAC signature verification of webhooks
        'webhook_secret' => env('BITGO_WEBHOOK_SECRET'),

        // Wallet Passphrases - Generate secure passphrases for each currency
        // These are used to authorize transfers and withdrawals
        // Store one passphrase per currency or use a master passphrase
        'wallet_passphrases' => [
            'btc' => env('BITGO_WALLET_PASSPHRASE_BTC'),
            'eth' => env('BITGO_WALLET_PASSPHRASE_ETH'),
            'ltc' => env('BITGO_WALLET_PASSPHRASE_LTC'),
            'bch' => env('BITGO_WALLET_PASSPHRASE_BCH'),
            'xrp' => env('BITGO_WALLET_PASSPHRASE_XRP'),
            'xlm' => env('BITGO_WALLET_PASSPHRASE_XLM'),
            'dash' => env('BITGO_WALLET_PASSPHRASE_DASH'),
            'zec' => env('BITGO_WALLET_PASSPHRASE_ZEC'),
            'trx' => env('BITGO_WALLET_PASSPHRASE_TRX'),
            'ada' => env('BITGO_WALLET_PASSPHRASE_ADA'),
            'sol' => env('BITGO_WALLET_PASSPHRASE_SOL'),
            'matic' => env('BITGO_WALLET_PASSPHRASE_MATIC'),
            'avax' => env('BITGO_WALLET_PASSPHRASE_AVAX'),
            'usdc' => env('BITGO_WALLET_PASSPHRASE_USDC'),
            'dai' => env('BITGO_WALLET_PASSPHRASE_DAI'),
        ],

        // Webhook URLs - Register these in BitGo Developer Portal
        'webhook_urls' => [
            'deposit' => env('APP_URL') . '/api/webhooks/bitgo/deposit',
            'withdrawal' => env('APP_URL') . '/api/webhooks/bitgo/withdrawal',
        ],

        // Supported Currencies Configuration
        'supported_currencies' => [
            'btc' => ['name' => 'Bitcoin', 'decimals' => 8, 'confirmations' => 1],
            'eth' => ['name' => 'Ethereum', 'decimals' => 18, 'confirmations' => 12],
            'ltc' => ['name' => 'Litecoin', 'decimals' => 8, 'confirmations' => 1],
            'bch' => ['name' => 'Bitcoin Cash', 'decimals' => 8, 'confirmations' => 1],
            'xrp' => ['name' => 'Ripple', 'decimals' => 6, 'confirmations' => 1],
            'xlm' => ['name' => 'Stellar', 'decimals' => 7, 'confirmations' => 1],
            'dash' => ['name' => 'Dash', 'decimals' => 8, 'confirmations' => 1],
            'zec' => ['name' => 'Zcash', 'decimals' => 8, 'confirmations' => 1],
            'trx' => ['name' => 'Tron', 'decimals' => 6, 'confirmations' => 1],
            'ada' => ['name' => 'Cardano', 'decimals' => 6, 'confirmations' => 1],
            'sol' => ['name' => 'Solana', 'decimals' => 9, 'confirmations' => 1],
            'matic' => ['name' => 'Polygon', 'decimals' => 18, 'confirmations' => 128],
            'avax' => ['name' => 'Avalanche', 'decimals' => 18, 'confirmations' => 1],
            'usdc' => ['name' => 'USD Coin', 'decimals' => 6, 'confirmations' => 12],
            'dai' => ['name' => 'Dai', 'decimals' => 18, 'confirmations' => 12],
        ],
    ],

];
