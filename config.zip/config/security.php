<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Security Settings
    |--------------------------------------------------------------------------
    |
    | This file holds security-related configurations for the application.
    | */
    'duplicate_submission_timeout' => env('DUPLICATE_SUBMISSION_TIMEOUT', 10),
];
