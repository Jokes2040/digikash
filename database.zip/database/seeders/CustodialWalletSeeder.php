<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Services\ExternalWithdrawal\Models\CustodialWallet;
use App\Services\ExternalWithdrawal\Models\CustodialWalletBalance;

class CustodialWalletSeeder extends Seeder
{
    public function run(): void
    {
        $wallets = [
            [
                'name' => 'BTC Hot Wallet',
                'currency' => 'BTC',
                'chain' => 'BTC',
                'rpc_url' => 'https://btc-rpc.example.com',
                'hot_wallet_address' => '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa',
                'encrypted_signing_key' => encrypt('btc_signing_key_example'),
                'enabled' => true,
            ],
            [
                'name' => 'ETH Hot Wallet',
                'currency' => 'ETH',
                'chain' => 'ETH',
                'rpc_url' => 'https://eth-rpc.example.com',
                'hot_wallet_address' => '0x742d35Cc6634C0532925a3b844Bc454e4438f44e',
                'encrypted_signing_key' => encrypt('eth_signing_key_example'),
                'enabled' => true,
            ],
            [
                'name' => 'USDT-TRC20 Hot Wallet',
                'currency' => 'USDT-TRC20',
                'chain' => 'TRON',
                'rpc_url' => 'https://tron-rpc.example.com',
                'hot_wallet_address' => 'T9yD14Nj9j7xAB4dbGeiX9h8unkKHxuW9',
                'encrypted_signing_key' => encrypt('tron_signing_key_example'),
                'enabled' => true,
            ],
            [
                'name' => 'USDT-ERC20 Hot Wallet',
                'currency' => 'USDT-ERC20',
                'chain' => 'ETH',
                'rpc_url' => 'https://eth-rpc.example.com',
                'hot_wallet_address' => '0x742d35Cc6634C0532925a3b844Bc454e4438f44e',
                'encrypted_signing_key' => encrypt('eth_usdt_signing_key_example'),
                'enabled' => true,
            ],
            [
                'name' => 'SOL Hot Wallet',
                'currency' => 'SOL',
                'chain' => 'SOL',
                'rpc_url' => 'https://sol-rpc.example.com',
                'hot_wallet_address' => 'So11111111111111111111111111111111111111112',
                'encrypted_signing_key' => encrypt('sol_signing_key_example'),
                'enabled' => true,
            ],
        ];

        foreach ($wallets as $walletData) {
            $wallet = CustodialWallet::create($walletData);
            CustodialWalletBalance::create([
                'custodial_wallet_id' => $wallet->id,
                'total' => 1000.00000000, // Example balance
                'available' => 1000.00000000,
                'reserved' => 0.00000000,
            ]);
        }
    }
}
