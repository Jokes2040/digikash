<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Services\ExternalWithdrawal\Models\BlockchainSetting;

class BlockchainSettingsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $settings = [
            [
                'chain_name' => 'BTC',
                'rpc_url' => 'https://btc-mainnet.g.alchemy.com/v2/YOUR_API_KEY', // Placeholder, replace with actual
                'hot_wallet_public_address' => 'bc1qexampleaddress', // Placeholder
                'encrypted_signing_key' => null, // To be set by admin
                'enabled' => true,
                'fee_fixed' => 0.0001,
                'fee_percent' => null,
                'min_withdrawal' => 0.001,
                'max_withdrawal' => 10.0,
            ],
            [
                'chain_name' => 'ETH',
                'rpc_url' => 'https://eth-mainnet.g.alchemy.com/v2/YOUR_API_KEY', // Placeholder
                'hot_wallet_public_address' => '0xExampleAddress', // Placeholder
                'encrypted_signing_key' => null,
                'enabled' => true,
                'fee_fixed' => 0.001,
                'fee_percent' => null,
                'min_withdrawal' => 0.01,
                'max_withdrawal' => 100.0,
            ],
            [
                'chain_name' => 'TRON',
                'rpc_url' => 'https://api.trongrid.io', // Placeholder
                'hot_wallet_public_address' => 'TExampleAddress', // Placeholder
                'encrypted_signing_key' => null,
                'enabled' => true,
                'fee_fixed' => 1.0,
                'fee_percent' => null,
                'min_withdrawal' => 10.0,
                'max_withdrawal' => 10000.0,
            ],
            [
                'chain_name' => 'SOL',
                'rpc_url' => 'https://api.mainnet-beta.solana.com', // Placeholder
                'hot_wallet_public_address' => 'ExampleSolAddress', // Placeholder
                'encrypted_signing_key' => null,
                'enabled' => true,
                'fee_fixed' => 0.000005,
                'fee_percent' => null,
                'min_withdrawal' => 0.01,
                'max_withdrawal' => 1000.0,
            ],
        ];

        foreach ($settings as $setting) {
            BlockchainSetting::create($setting);
        }
    }
}
