<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('bit_go_alerts', function (Blueprint $table) {
            $table->id();
            $table->enum('type', ['deposit_failure', 'withdrawal_failure', 'webhook_error', 'api_connectivity', 'suspicious_transaction']);
            $table->enum('severity', ['info', 'warning', 'critical'])->default('warning');
            $table->string('message');
            $table->json('details')->nullable();
            $table->unsignedBigInteger('user_id')->nullable();
            $table->unsignedBigInteger('transaction_id')->nullable();
            $table->unsignedBigInteger('webhook_event_id')->nullable();
            $table->timestamp('resolved_at')->nullable();
            $table->unsignedBigInteger('resolved_by')->nullable();
            $table->timestamps();

            $table->index(['type', 'severity']);
            $table->index('user_id');
            $table->index('resolved_at');
            $table->index('created_at');

            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('transaction_id')->references('id')->on('transactions')->onDelete('cascade');
            $table->foreign('webhook_event_id')->references('id')->on('bitgo_webhook_events')->onDelete('cascade');
            $table->foreign('resolved_by')->references('id')->on('admins')->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('bitgo_alerts');
    }
};
