<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('bitgo_settings', function (Blueprint $table) {
            $table->enum('environment', ['production', 'staging', 'testnet'])->default('production')->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('bitgo_settings', function (Blueprint $table) {
            $table->enum('environment', ['production', 'staging'])->default('production')->change();
        });
    }
};
