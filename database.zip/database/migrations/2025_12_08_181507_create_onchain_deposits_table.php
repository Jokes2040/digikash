<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('onchain_deposits', function (Blueprint $table) {
            $table->id();
            $table->foreignId('deposit_address_id')->constrained('deposit_addresses')->onDelete('cascade');
            $table->string('tx_hash')->unique();
            $table->decimal('amount', 18, 8);
            $table->integer('confirmations')->default(0);
            $table->enum('status', ['pending', 'confirmed', 'failed'])->default('pending');
            $table->timestamp('processed_at')->nullable();
            $table->timestamps();

            $table->index(['tx_hash']);
            $table->index(['status']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('onchain_deposits');
    }
};
