<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('withdrawals', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('currency', 10);
            $table->decimal('amount', 30, 8);
            $table->string('destination_address');
            $table->decimal('network_fee', 30, 8)->nullable();
            $table->decimal('platform_fee', 30, 8)->nullable();
            $table->enum('status', ['pending', 'signed', 'broadcasted', 'confirmed', 'failed'])->default('pending');
            $table->string('tx_hash')->nullable();
            $table->string('idempotency_key')->unique();
            $table->text('signed_tx')->nullable();
            $table->integer('broadcast_attempts')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('withdrawals');
    }
};
