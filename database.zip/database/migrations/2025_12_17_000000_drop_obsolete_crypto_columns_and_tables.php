<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Drop obsolete columns from withdrawals table if they exist
        Schema::table('withdrawals', function (Blueprint $table) {
            if (Schema::hasColumn('withdrawals', 'signed_tx')) {
                $table->dropColumn('signed_tx');
            }
            if (Schema::hasColumn('withdrawals', 'broadcast_attempts')) {
                $table->dropColumn('broadcast_attempts');
            }
        });

        // Drop obsolete tables in correct order (child tables first)
        Schema::dropIfExists('custodial_wallet_balances');
        Schema::dropIfExists('custodial_wallets');
        Schema::dropIfExists('onchain_deposits');
        Schema::dropIfExists('deposit_addresses');
        Schema::dropIfExists('blockchain_settings');
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Recreate tables if needed, but since obsolete, no need
        Schema::table('withdrawals', function (Blueprint $table) {
            $table->text('signed_tx')->nullable();
            $table->integer('broadcast_attempts')->default(0);
        });

        // Note: Not recreating dropped tables as they are obsolete
    }
};
