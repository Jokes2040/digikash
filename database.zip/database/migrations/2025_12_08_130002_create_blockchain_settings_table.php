<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('blockchain_settings', function (Blueprint $table) {
            $table->id();
            $table->string('chain_name'); // BTC, ETH, TRON, SOL, etc.
            $table->string('rpc_url');
            $table->string('hot_wallet_public_address');
            $table->text('encrypted_signing_key')->nullable();
            $table->boolean('enabled')->default(true);
            $table->decimal('fee_fixed', 30, 8)->nullable();
            $table->decimal('fee_percent', 5, 2)->nullable();
            $table->decimal('min_withdrawal', 30, 8)->nullable();
            $table->decimal('max_withdrawal', 30, 8)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('blockchain_settings');
    }
};
