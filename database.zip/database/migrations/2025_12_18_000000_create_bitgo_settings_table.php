<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('bitgo_settings', function (Blueprint $table) {
            $table->id();
            $table->enum('environment', ['production', 'staging', 'testnet'])->default('production');
            $table->text('api_key')->nullable();
            $table->text('webhook_secret')->nullable();
            $table->text('wallet_passphrase')->nullable();
            $table->timestamps();

            $table->unique('environment');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('bitgo_settings');
    }
};
